package com.example.uascobacoba

data class Akun(
    var id: String = "",
    val nama: String = "",
    val nim: String = "",
    val username: String = "",
    val email: String = "",
    val password : String = "",
    val isAdmin: Boolean = false,
)
