package com.example.uascobacoba

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.uascobacoba.databinding.FragmentTravelListBinding


class TravelListFragment : Fragment() {

    private lateinit var binding: FragmentTravelListBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentTravelListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mainActivity = MainActivity.getInstance()!!
        mainActivity.getTravel()
        with(binding) {

            favUser.setOnClickListener {
                findNavController().navigate(TravelListFragmentDirections.actionTravelListFragmentToFavouriteFragment())
            }

            mainActivity.getTravelLiveData().observe(viewLifecycleOwner) {
                if(it != null) {
                    rv2.visibility = View.VISIBLE
                    rv2.apply {
                        adapter = TravelUserAdapter(it, onHistory =
                        {
                        val hisDb = HistoryDb (
                            uid = mainActivity.getUID(),
                            stasiunAsal = it.stasiunAsal,
                            stasiunTujuan = it.stasiunTujuan,
                            kelasKereta = it.kelasKereta,
                            harga = it.harga,
                            waktu = it.waktu
                        )
                        mainActivity.insertHistory(hisDb)
                        Toast.makeText(context, "History Added", Toast.LENGTH_SHORT).show()
                        }, onFavourite = {
                            val travelDb = TravelDb (
                                uid = mainActivity.getUID(),
                                stasiunAsal = it.stasiunAsal,
                                stasiunTujuan = it.stasiunTujuan,
                                kelasKereta = it.kelasKereta,
                                harga = it.harga,
                                waktu = it.waktu
                            )
                            mainActivity.insertFavorite(travelDb)
                            Toast.makeText(context, "Favorite Added", Toast.LENGTH_SHORT).show()
                        })
                        layoutManager = androidx.recyclerview.widget.LinearLayoutManager(context)
                    }
                } else {
                    rv2.visibility = View.GONE
                }
            }
        }
    }

}