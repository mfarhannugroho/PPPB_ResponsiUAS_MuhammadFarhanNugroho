package com.example.uascobacoba

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.uascobacoba.databinding.ListHistoryBinding

class HistoryAdapter(private val travelList: List<HistoryDb>) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {
    inner class ViewHolder(private val binding: ListHistoryBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(travel: HistoryDb) {
            binding.asalHistory.text = travel.stasiunAsal
            binding.tujuanHistory.text = travel.stasiunTujuan
            binding.kelasHistory.text = travel.kelasKereta
            binding.totalHistory.text = "Rp.${travel.harga}"
            binding.tanggalHistory.text = travel.waktu
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return travelList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(travelList[position])
    }
}