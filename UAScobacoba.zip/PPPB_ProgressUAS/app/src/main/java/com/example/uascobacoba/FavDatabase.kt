package com.example.uascobacoba

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


@Database(entities = [TravelDb::class, HistoryDb::class], version = 1, exportSchema = false)
abstract class FavDatabase: RoomDatabase() {
    abstract fun travelDao(): TravelDao
    abstract fun historyDao(): HistoryDao
    companion object {
        @Volatile
        private var instance: FavDatabase? = null

        fun getInstance(context: Context): FavDatabase? {
            synchronized(FavDatabase::class.java) {
                if(instance == null) {
                    instance = Room.databaseBuilder(context.applicationContext,
                    FavDatabase::class.java, "travel.db").build()
                }
                return instance
            }
        }
    }
}