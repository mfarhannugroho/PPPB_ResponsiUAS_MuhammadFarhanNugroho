package com.example.uascobacoba

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.uascobacoba.databinding.ListFavouriteBinding

class FavoriteAdapter(private val travelList: List<Travel>) : RecyclerView.Adapter<FavoriteAdapter.ViewHolder>() {
    inner class ViewHolder(private val binding: ListFavouriteBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(travel: Travel) {
            binding.asalFav.text = travel.stasiunAsal
            binding.tujuanFav.text = travel.stasiunTujuan
            binding.kelasFav.text = travel.kelasKereta
            binding.totalFav.text = "Rp.${travel.harga}"
            binding.tanggalFav.text = travel.waktu
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListFavouriteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return travelList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(travelList[position])
    }
}