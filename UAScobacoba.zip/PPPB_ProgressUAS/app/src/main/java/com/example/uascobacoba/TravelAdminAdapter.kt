package com.example.uascobacoba

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.uascobacoba.databinding.ListDashboardBinding

class TravelAdminAdapter(private val travelList: List<Travel>, private val onEdit: (Travel) -> Unit = {},
                         private val onDelete: (Travel) -> Unit = {}) : RecyclerView.Adapter<TravelAdminAdapter.ViewHolder>() {
    inner class ViewHolder(private val binding: ListDashboardBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(travel: Travel) {
            binding.asalText.text = travel.stasiunAsal
            binding.tujuanText.text = travel.stasiunTujuan
            binding.kelas.text = travel.kelasKereta
            binding.harga.text = "Rp.${travel.harga}"
            binding.tanggal.text = travel.waktu
            binding.updateButton.setOnClickListener {
                onEdit(travel)
            }
            binding.deleteButton.setOnClickListener {
                onDelete(travel)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListDashboardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return travelList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(travelList[position])
    }
}