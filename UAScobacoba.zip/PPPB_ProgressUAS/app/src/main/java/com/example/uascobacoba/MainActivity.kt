package com.example.uascobacoba

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.viewpager2.widget.ViewPager2
import com.example.uascobacoba.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ViewPagerAdapter

    private lateinit var preferences: Preferences

    private lateinit var firestore: FirebaseFirestore
    private lateinit var accountCollection: CollectionReference
    private lateinit var travelCollection: CollectionReference

    private lateinit var roomdb: FavDatabase
    private lateinit var favDao: TravelDao
    private lateinit var hisDao: HistoryDao
    private lateinit var executorService: ExecutorService

    private val travelData: MutableLiveData<List<Travel>> by lazy {
        MutableLiveData<List<Travel>>()
    }

    companion object {
        private var instance: MainActivity? = null

        fun getInstance(): MainActivity? {
            return instance!!
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        instance = this

        preferences = Preferences.getInstance(this)

        firestore = FirebaseFirestore.getInstance()
        accountCollection = firestore.collection("account")
        travelCollection = firestore.collection("travel")

        roomdb = FavDatabase.getInstance(this)!!
        favDao = roomdb.travelDao()
        hisDao = roomdb.historyDao()
        executorService = Executors.newSingleThreadExecutor()

        with(binding) {
            tabLayout.addTab(tabLayout.newTab().setText("Login"))
            tabLayout.addTab(tabLayout.newTab().setText("Register"))

            val fragmentManager: FragmentManager = supportFragmentManager
            adapter = ViewPagerAdapter(fragmentManager, lifecycle)

            viewPager.adapter = adapter

            tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) {
                    viewPager.currentItem = tab.position
                }

                override fun onTabUnselected(tab: TabLayout.Tab) {}

                override fun onTabReselected(tab: TabLayout.Tab) {}
            })

            viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    tabLayout.selectTab(tabLayout.getTabAt(position))
                }
            })

            if(preferences.isLoggedIn()) {
                if(preferences.isAdmin()) {
                    val intent = Intent(this@MainActivity, AdminActivity::class.java)
                    startActivity(intent)
                } else {
                    val intent = Intent(this@MainActivity, UserActivity::class.java)
                    startActivity(intent)
                }
            }
        }
    }

    fun getAccountInfo(): Pair<String, String> {
        return Pair(preferences.getFullName(), preferences.getNim())
    }

    fun insertHistory(historyDb: HistoryDb) {
        executorService.execute {
            hisDao.insertHistory(historyDb)
        }
    }

    fun getAllHistory(): LiveData<List<HistoryDb>> {
        return hisDao.getHistoryById(preferences.getUID())
    }

    fun insertFavorite(travel: TravelDb) {
        executorService.execute {
            favDao.insertTravel(travel)
        }
    }

    fun getAllFavorite(): LiveData<List<Travel>> {
        return favDao.getTravelById(preferences.getUID())
    }

    fun getTravelLiveData(): MutableLiveData<List<Travel>> {
        return travelData
    }

    fun getTravel() {
        travelCollection.addSnapshotListener { value, error ->
            if(error != null) {
                Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show()
            }
            val travel = value?.toObjects(Travel::class.java)
            if(travel != null) {
                travelData.postValue(travel)
            }
        }
    }

    fun deleteTravel(travel: Travel) {
        travelCollection.document(travel.id).delete()
            .addOnSuccessListener {
                Log.d("TravelActivity", "DocumentSnapshot successfully deleted!")
            }
            .addOnFailureListener { e ->
                Log.w("TravelActivity", "Error deleting document", e)
            }
    }

    fun updateTravel(travel: Travel) {
        travelCollection.document(travel.id).set(travel)
            .addOnSuccessListener {
                Log.d("TravelActivity", "DocumentSnapshot successfully updated!")
                Toast.makeText(this, "Data Berhasilal Diupdate", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.w("TravelActivity", "Error updating document", e)
            }
    }
    fun addTravel(stasiunAsal: String, stasiunTujuan: String, kelasKereta: String, harga: String, waktu: String) {
        val travel = Travel(
            stasiunAsal = stasiunAsal,
            stasiunTujuan = stasiunTujuan,
            kelasKereta = kelasKereta,
            harga = harga,
            waktu = waktu
        )
        travelCollection.add(travel)
            .addOnSuccessListener { documentReference ->
                travel.id = documentReference.id
                documentReference.set(travel)
                    .addOnSuccessListener {
                        Log.d("TravelActivity", "DocumentSnapshot added with ID: ${documentReference.id}")
                    }
                    .addOnFailureListener { e ->
                        Log.w("TravelActivity", "Error adding document", e)
                    }
            }
            .addOnFailureListener { e ->
                Log.w("TravelActivity", "Error adding document", e)
            }
    }

     fun getUID(): String {
        return preferences.getUID()
    }

    private fun login(username: String, password: String) {
        if(username== preferences.getUsername() && password == preferences.getPassword()) {
            preferences.setLoggedIn(true, preferences.isAdmin())
            if(preferences.isAdmin()) {
                val intent = Intent(this, AdminActivity::class.java)
                startActivity(intent)
            } else {
                val intent = Intent(this, UserActivity::class.java)
                startActivity(intent)
            }
            Toast.makeText(this, "Login Berhasil", Toast.LENGTH_SHORT).show()
        } else {
            preferences.clear()
            Toast.makeText(this, "Login Gagal", Toast.LENGTH_SHORT).show()
        }
    }

    fun getAkun(username: String, password: String) {
        accountCollection.whereEqualTo("username", username).limit(1).get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val data = documents.documents[0].data
                    if (data != null) {
                        preferences.saveUID(data["id"].toString())
                        preferences.saveFullName(data["nama"].toString())
                        preferences.saveUsername(data["username"].toString())
                        preferences.saveNim(data["nim"].toString())
                        preferences.saveEmail(data["email"].toString())
                        preferences.savePassword(data["password"].toString())
                        if(data["admin"] == true) {
                            preferences.setAdmin()
                        }
                        login(username, password)
                    }
                }
            }
            .addOnFailureListener {
                it.printStackTrace()
            }

    }

    fun registerAccount(nama: String, nim: String, username: String, email: String, password: String) {
        val akun = Akun(
            nama = nama,
            nim = nim,
            username = username,
            email = email,
            password = password
        )
        accountCollection.add(akun)
            .addOnSuccessListener { documentReference ->
                akun.id = documentReference.id
                documentReference.set(akun)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Berhasil Register", Toast.LENGTH_SHORT).show()
                        binding.tabLayout.selectTab(binding.tabLayout.getTabAt(0))
                    }
                    .addOnFailureListener { e ->
                        println("Error adding document: $e")
                    }
            }
            .addOnFailureListener { e ->
                println("Error adding document: $e")
            }
    }

    fun logout() {
        preferences.clear()
    }
}