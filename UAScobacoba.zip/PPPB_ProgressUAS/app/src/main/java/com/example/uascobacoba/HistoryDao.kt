package com.example.uascobacoba

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface HistoryDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertHistory(historyDb: HistoryDb)

    @Query("SELECT * FROM history where uid = :uid")
    fun getHistoryById(uid: String): LiveData<List<HistoryDb>>
}