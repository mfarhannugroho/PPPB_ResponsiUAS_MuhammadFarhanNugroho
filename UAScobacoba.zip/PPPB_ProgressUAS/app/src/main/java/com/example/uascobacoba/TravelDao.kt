package com.example.uascobacoba

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface TravelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertTravel(travelDb: TravelDb)

    @Query("SELECT * FROM travel where uid = :uid")
    fun getTravelById(uid: String): LiveData<List<Travel>>
}