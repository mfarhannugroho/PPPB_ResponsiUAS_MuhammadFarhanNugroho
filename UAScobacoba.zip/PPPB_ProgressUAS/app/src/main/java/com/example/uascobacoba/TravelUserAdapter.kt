package com.example.uascobacoba

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.uascobacoba.databinding.ListUserBinding

class TravelUserAdapter (private val travelList: List<Travel>, private val onFavourite: (Travel) -> Unit = {},
                         private val onHistory: (Travel) -> Unit = {}) : RecyclerView.Adapter<TravelUserAdapter.ViewHolder>() {
    inner class ViewHolder(private val binding: ListUserBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(travel: Travel) {
            binding.asalUser.text = travel.stasiunAsal
            binding.tujuanUser.text = travel.stasiunTujuan
            binding.kelasUser.text = travel.kelasKereta
            binding.totalUser.text = "Rp.${travel.harga}"
            binding.tanggalUser.text = travel.waktu
            binding.favouriteButton.setOnClickListener {
                onFavourite(travel)
            }
            binding.buyButton.setOnClickListener {
                onHistory(travel)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return travelList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(travelList[position])
    }
}