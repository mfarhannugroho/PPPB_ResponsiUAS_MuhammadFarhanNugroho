package com.example.uascobacoba

data class Travel(
    var id: String = "",
    val stasiunAsal: String = "",
    val stasiunTujuan: String = "",
    val kelasKereta: String = "",
    val harga: String = "",
    val waktu: String = "",
)
